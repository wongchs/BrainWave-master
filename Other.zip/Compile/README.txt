Step 1.
https://github.com/brainflow-dev/brainflow/archive/refs/tags/5.12.1.zip
https://developer.android.com/ndk/downloads
Extract branflow & andoroid ndk as a folder in current directory

Step 2.
https://cmake.org/download/
Install cmake and make sure it can find in PATH

Step 3.
Reconfig android API level in compile.bat and run it in admin

Step 4.
Import lib to android from .\brainflow-x.xx.x\tools\jniLibs